import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Modificacion2 {

    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(System.in);
        int size;
        System.out.println("Inserte número: ");
        size=in.nextInt();

        Punto p = new Punto(1,4);

        Punto array[] = new Punto[size];
        creaArray(size,array);
        //System.out.println(Arrays.asList(array));


        long inicio = System.nanoTime();											//Contiene el tiempo, cuando el programa justo empieza a ordenar el vector

        quicksortSinRecursion(array, 0, array.length-1, p);

        long fin = System.nanoTime() - inicio;

        System.out.println(Arrays.asList(array));

        System.out.println("\nEl tiempo en ordenar los vectores es: "+ 1e-9*fin+" segundos"); //Printeo el tiempo que ha tardado en ordenarlo

        in.close();
        /* tengo que ordenar los puntos que tiene el array por la distancia respecto al punto p */
    }
    public static Punto[] creaArray(int size, Punto[] array){
        float u;
        float v;
        Random randomobj1 = new Random(100);
        for (int i=0;i<size;i++){
            u= randomobj1.nextFloat();
            v= randomobj1.nextFloat();
            array[i] =  new Punto(u, v);
        }
        return array;
    }

    public static Punto[] quicksortSinRecursion(Punto[] arr, int lower, int upper, Punto x) {
        while (!(lower >= upper || lower < 0)) {

            int t = partition(arr, lower, upper, x);

            quicksortSinRecursion(arr, lower, t - 1, x);
            //quicksort(arr, t + 1, upper, x);
            lower=t+1;
        }
        return arr;
    }


    private static int partition(Punto[] arr, int lower, int upper, Punto x) {
        int i;
        double distanciaPunto;
        Punto temp = new Punto();
        Punto pivot = new Punto();
        pivot = arr[upper];
        double distanciaPivot = Punto.distancia(x,pivot);
        i = lower - 1;

        for (int j = lower; j<upper;j++) {
            distanciaPunto = Punto.distancia(x, arr[j]);
            if (distanciaPunto<=distanciaPivot){ // If the current element distance is less than or equal to the pivot distance
                i++;
                temp = arr[i];  //swap
                arr[i] = arr[j];
                arr[j] = temp;

            }
        }
        i++;
        temp = arr[i];
        arr[i] = arr[upper];
        arr[upper] = temp;

        return i;
    }


}
