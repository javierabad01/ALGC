import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Modificacion1 {

    public static void main(String[] args) throws Exception {
            Scanner in = new Scanner(System.in);
            int size, c;
            System.out.println("Inserte número: ");
            //size=in.nextInt();
            size=50000;
            c=in.nextInt();

            Punto p = new Punto(1,4);

            Punto[] array = new Punto[size];

           // System.out.println(Arrays.asList(array));

            long inicio = System.nanoTime();											//Contiene el tiempo, cuando el programa justo empieza a ordenar el vector

            quicksortC(array, 0, array.length-1, p, c);

            long fin = System.nanoTime() - inicio;



            System.out.println("\nEl tiempo en ordenar los vectores es: "+ 1e-9*fin+" segundos"); //Printeo el tiempo que ha tardado en ordenarlo

            in.close();
            /* tengo que ordenar los puntos que tiene el array por la distancia respecto al punto p */
        }
    public static Punto[] creaArray(int size, Punto[] array){
            float u;
            float v;
            Random randomobj1 = new Random(100);
            for (int i=0;i<size;i++){
                u= randomobj1.nextFloat();
                v= randomobj1.nextFloat();
                array[i] =  new Punto(u, v);
            }
            return array;
        }

    public static void insercionDirectaArray(Punto[] aPuntos, Punto punto, int principio, int fin){
            int p, j;
            float aux;
            Punto puntoAux;
            for (p = principio + 1 ; p <= fin; p++){                                           // desde el segundo elemento hasta
                puntoAux=aPuntos[p];
                aux = Punto.distancia(punto, aPuntos[p]);                         // el final, guardamos el elemento y
                j = p - 1;                                                            // empezamos a comprobar con el anterior
                while ((j >= 0) && (aux < Punto.distancia(punto, aPuntos[j]))){   // mientras queden posiciones y el
                                                                                    // valor de aux sea menor que los
                    aPuntos[j + 1] = aPuntos[j];                                     // de la izquierda, se desplaza a
                    j--;                                                   // la derecha
                }
                aPuntos[j + 1] = puntoAux;       // colocamos aux en su sitio
            }
        }


    public static Punto[] quicksortC(Punto[] arr, int lower, int upper, Punto x, int c){
        if (upper-lower+1>c){
                if (!(lower >= upper || lower <0)){
                    int t = partition(arr, lower, upper, x);
                    quicksortC(arr, lower, t - 1, x, c);
                    quicksortC(arr, t + 1, upper, x, c);
                }
                else{
                    insercionDirectaArray(arr, x, lower, upper);
                }
            }
            return arr;
        }
    private static int partition(Punto[] arr, int lower, int upper, Punto x) {
            int i;
            double distanciaPunto;
            Punto temp = new Punto();
            Punto pivot = new Punto();
            pivot = arr[upper];
            double distanciaPivot = Punto.distancia(x,pivot);
            i = lower - 1;

            for (int j = lower; j<upper;j++) {
                distanciaPunto = Punto.distancia(x, arr[j]);
                if (distanciaPunto<=distanciaPivot){ // If the current element distance is less than or equal to the pivot distance
                    i++;
                    temp = arr[i];  //swap
                    arr[i] = arr[j];
                    arr[j] = temp;

                }
            }
            i++;
            temp = arr[i];
            arr[i] = arr[upper];
            arr[upper] = temp;

            return i;
        }


}
