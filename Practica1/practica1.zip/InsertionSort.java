import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class InsertionSort {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
	    int size;
	    System.out.println("Inserte número: ");
	    size=in.nextInt();


        Punto p = new Punto(1,4);


        Punto array[] = new Punto[size];


        creaArray(size,array);

        //System.out.println(Arrays.asList(array));
        long inicio = System.nanoTime();											//Contiene el tiempo, cuando el programa justo empieza a ordenar el vector


        insercionDirectaArray(array, p);
        long fin = System.nanoTime() - inicio;										//De la resta se obtiene el tiempo que ha tardado el programa en ordenar el array

        System.out.println(Arrays.asList(array));

        System.out.println("\nEl tiempo en ordenar los vectores es: "+ 1e-9*fin+" segundos"); //Printeo el tiempo que ha tardado en ordenarlo
        in.close();
        /* tengo que ordenar los puntos que tiene el array por la distancia respecto al punto p */
    }

    public static Punto[] creaArray(int size, Punto[] array){
        float u;
        float v;
        Random randomobj1 = new Random(100);
        for (int i=0;i<size;i++){
            u= randomobj1.nextFloat();
            v= randomobj1.nextFloat();
            array[i] =  new Punto(u, v);
        }
        return array;
    }
/*
    public static void insercionDirecta(ArrayList<Punto>aPuntos, Punto punto){                                            
        int p, j;
        float aux;
        Punto puntoAux;
        for (p = 1; p < aPuntos.size(); p++){                                           // desde el segundo elemento hasta
                  puntoAux=aPuntos.get(p);
                  aux = Punto.distancia(punto, aPuntos.get(p));                         // el final, guardamos el elemento y
                  j = p - 1;                                                            // empezamos a comprobar con el anterior
                  while ((j >= 0) && (aux < Punto.distancia(punto, aPuntos.get(j)))){   // mientras queden posiciones y el                                
                                                                                        // valor de aux sea menor que los
                                aPuntos.set((j+1), aPuntos.get(j));
                                 //A[j + 1] = A[j];                                     // de la izquierda, se desplaza a
                                 j--;                                                   // la derecha
                  }
                  aPuntos.set((j+1),puntoAux);
                  //A[j + 1] = aux;       // colocamos aux en su sitio
        }
    }
*/
    public static void insercionDirectaArray(Punto[] aPuntos, Punto punto){                                            
        int p, j;
        float aux;
        Punto puntoAux;
        for (p = 1; p < aPuntos.length; p++){                                           // desde el segundo elemento hasta
                  puntoAux=aPuntos[p];
                  aux = Punto.distancia(punto, aPuntos[p]);                         // el final, guardamos el elemento y
                  j = p - 1;                                                            // empezamos a comprobar con el anterior
                  while ((j >= 0) && (aux < Punto.distancia(punto, aPuntos[j]))){   // mientras queden posiciones y el                                
                                                                                        // valor de aux sea menor que los
                                aPuntos[j + 1] = aPuntos[j];                                     // de la izquierda, se desplaza a
                                 j--;                                                   // la derecha
                  }
                  aPuntos[j + 1] = puntoAux;       // colocamos aux en su sitio
        }
    }

}
