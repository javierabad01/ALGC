public class Punto {
        private float u;
        private float v;

        public Punto (float u, float v){
            this.u = u;
            this.v = v;
        }
        public Punto(){
            u=0;
            v=0;
        }


        public static float distancia (Punto p1, Punto p2){

            return (float)Math.sqrt(((p2.u-p1.u)*(p2.u-p1.u))+((p2.v-p1.v)*(p2.v-p1.v)));
        }
        public String toString(){
            return "("+u+ " "+v +")";
        }

}
